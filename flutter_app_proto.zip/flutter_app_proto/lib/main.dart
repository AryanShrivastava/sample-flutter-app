import 'package:flutter/material.dart';
import './app_screens/drawer_file.dart';
import './app_screens/scroll_view.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        home:Scaffold(
        appBar: AppBar(title: Text('Passion pavers app dev')),
        drawer: DrawerFileMenu(),
        body: TabScreen1(),
            backgroundColor: Colors.yellow[200]
        ),
    );
  }
}
