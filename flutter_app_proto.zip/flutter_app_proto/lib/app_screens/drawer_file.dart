import 'package:flutter/material.dart';

class DrawerFileMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: DrImg(),
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
          ),
          ListTile(
            title: Text('WHY FLUTTER?'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Item_1()));
            },
          ),
          ListTile(
            title: Text('ABOUT FLUTTER'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Item_2()));
            },
          ),
          ListTile(
            title: Text('CLICK TO EXPLOR'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Item_3()));
            },
          ),
          ListTile(
            title: Text('About us'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Item_4()));
            },
          ),
        ],
      ),
    );
  }
}

class Item_1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        title: Text("WHY FLUTTER?"),
      ),
      body: new ListView(children: <Widget>[
        Fad(),
        Container(
          padding: EdgeInsets.only(left: 10.0, top: 10.0, right: 5.0),
          child: Text(
              "ADVANTAGES:\n"
              "1)Extremely Fast App Development\n"
              "2)Faster Running of Applications\n"
              "3)Reduced Efforts of Testing\n"
              "4)Access of Native Features\n"
              "5)Reactive Framework\n"
              "6)Excellent User Interfaces\n"
              "7)Can work for both android and ios\n",
              textDirection: TextDirection.ltr,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0,
                  color: Colors.brown)),
        ),
      ]),
    );
  }
}

class Item_2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown,
      appBar: AppBar(
        title: Text("ABOUT FLUTTER"),
      ),
      body: new ListView(children: <Widget>[
        F(),
        Container(
          padding: EdgeInsets.only(left: 10.0, top: 10.0, right: 5.0),
          child: Text(
              "About:\n"
              "\n"
              "Flutter is an open-source mobile application\n"
              " development framework created by Google.\n"
              " It is used to develop applications for Android and iOS.\n "
              "As well as being the primary method of \n"
              "creating applications for Google Fuchsia\n"
              "On December 4th, 2018,\n"
              "Flutter 1.0 was released at the Flutter Live event,\n"
              " denoting the first stable version of the Framework.\n",
              textDirection: TextDirection.ltr,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0,
                  color: Colors.white)),
        ),
      ]),
    );
  }
}

class Item_3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[200],
      appBar: AppBar(
        title: Text("item3"),
      ),
      body: new ListView(children: <Widget>[
        Fd(),
        Container(
          padding: EdgeInsets.only(left: 10.0, top: 10.0, right: 5.0),
          child: Text(
              "Flutter SDK lets you build an android application quickly with a comparatively low end machine as well.\n"
              "This means your investment kit can function with lighter resources\n"
              " most of which shall be easily travel with.\n"
              "It is capable of delivering some super smooth and responsive animations to UI elements and appeals to the interest of several industry verticals\n",
              maxLines: 9,
              textDirection: TextDirection.ltr,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0,
                  color: Colors.redAccent)),
        ),
      ]),
    );
  }
}

class Item_4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        title: Text("About us"),
      ),
      body: new ListView(children: <Widget>[
        Passion(),
        Container(
            padding: EdgeInsets.only(left: 10.0, top: 10.0, right: 5.0),
            child: Text(
              "This app is developed by two Undergrad students of Srm University currently studying in first year of B.tech CSE.\n"
                  "\n"
                  "DEV ARYAN SHRIVASTAVA:\n"
                  "He is a hardworking student with an urge to take develop new things,\n"
                  "the never gives up.\n"
                  "He is having hands on Technical skils :\n"
                  "FLUTTER,\n"
                  "C\n,"
                  "PYTHON(basic),\n"
                  "HTML,\n"
                  "CSS\n"
                  "\n"
                  "He is enthusiatic,serious toward his work and has high aspirations and dreams.\n"
                  "\n"
                  "DHARINI GROVER:\n"
                  "She is a girl with high aspirations and dreams.She is good in providing ideas.\n"
                  "She is having hands on :\n"
                  "C ,\n"
                  "JAVA,\n"
                  "FLUTTER,\n"
                  "HTML ,\n"
                  "CSS\n"
                  "She is hardworking with a postive attitude,she never gives up\n",
              textDirection: TextDirection.ltr,
              style: TextStyle(
                  decoration: TextDecoration.none,
                  fontSize: 18.0,
                  //fontFamily: 'Raleway',
                  // fontWeight: FontWeight.w700,
                  color: Colors.black),
            )),
      ]),
    );
  }
}

class Passion extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AssetImage assetImage = AssetImage('images/pp.png');
    Image image = Image(image: assetImage, width: 300, height: 200.0);
    return Container(
      child: image,
    );
  }
}

class DrImg extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AssetImage assetImage = AssetImage('images/dr.jpeg');
    Image image = Image(image: assetImage, width: 400, height: 400.0);
    return Container(
      child: image,
    );
  }
}

class Fad extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AssetImage assetImage = AssetImage('images/fad.jpg');
    Image image = Image(image: assetImage, width: 250, height: 250.0);
    return Container(
      child: image,
    );
  }
}

class F extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AssetImage assetImage = AssetImage('images/f.png');
    Image image = Image(image: assetImage, width: 250, height: 250.0);
    return Container(
      child: image,
    );
  }
}

class Fd extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AssetImage assetImage = AssetImage('images/fd.png');
    Image image = Image(image: assetImage, width: 250, height: 250.0);
    return Container(
      child: image,
    );
  }
}
