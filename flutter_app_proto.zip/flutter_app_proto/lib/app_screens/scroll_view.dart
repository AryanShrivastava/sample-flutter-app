import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';

class TabScreen1 extends StatelessWidget {
  @override
  Widget imageCarousel = new Container(
    height: 200.0,
    child: new Carousel(
      boxFit: BoxFit.cover,
      images: [
        new ExactAssetImage('images/d1.jpg'),
        new ExactAssetImage('images/d2.jpg'),
        new ExactAssetImage('images/d3.jpg'),
        new ExactAssetImage('images/d4.jpg'),
      ],
      animationCurve: Curves.fastOutSlowIn,
      animationDuration: Duration(milliseconds: 1000),
    ),
  );

  Widget build(BuildContext context) {
    return new MaterialApp(
      debugShowCheckedModeBanner: false,
      home: new Scaffold(
        backgroundColor: Colors.yellow[200],
        body: new ListView(children: <Widget>[
          imageCarousel,
          MyLayout(),
          Quote (),
        ]),
      ),
    );
  }
}

showAlertDialog(BuildContext context) {
  // set up the buttons
  // Widget remindButton = FlatButton(
  // child: Text("Remind me later"),
  //onPressed:  () {},
  // );
  Widget cancelButton = FlatButton(
    child: Text("Cancel"),
    onPressed: () {},
  );
  Widget likeButton = FlatButton(
    child: Text("like"),
    onPressed: () {},
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Quote of the day"),
    content: Text(
          "Imagination is more important than knowledge. For knowledge is limited,"
            " whereas imagination embraces the entire world, stimulating progress, giving birth to evolution.\n"

          "— Albert Einstein"),
    actions: [
      //remind Button,
      cancelButton,
      likeButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

class MyLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: RaisedButton(
        child: Text('please click'),
        onPressed: () {
          showAlertDialog(context);
        },
      ),
    );
  }
}

class Quote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(
        "What is App devlopment ?\n"
            "\n"
            "Mobile app development is the act or process by which a mobile app is developed for mobile devices,"
            " such as personal digital assistants, enterprise digital assistants or mobile phones.",
        maxLines: 8,
        textDirection: TextDirection.ltr,
        style: TextStyle(
            decoration: TextDecoration.none,
            fontSize: 20.0,
            //fontFamily: 'Raleway',
            // fontWeight: FontWeight.w700,
            color: Colors.black),
      ),
    );
  }
}
